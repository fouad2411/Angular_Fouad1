export class numeros {
  id:number=0
  n1:number=0
  n2:number=0
  n3:number=0
  n4:number=0
  n5:number=0
  n6:number=0
  constructor(id:number,n1:number,n2:number,n3:number,n4:number,n5:number,n6:number){
    this.id=id
    this.n1 = n1;
    this.n2 =n2;
    this.n3=n3;
    this.n4 =n4;
    this.n5 =n5;
    this.n6 =n6;

  }
}
