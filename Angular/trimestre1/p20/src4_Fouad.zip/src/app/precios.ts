export class Precios {
  fruta:string=""
  precio:string= ""
  constructor(fruta:string,precio:string ) {
    this.fruta = fruta;
    this.precio = precio;
  }
}
