export class Imagenes {
}
