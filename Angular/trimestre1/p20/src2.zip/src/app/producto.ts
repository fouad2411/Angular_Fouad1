export class Producto {
}
